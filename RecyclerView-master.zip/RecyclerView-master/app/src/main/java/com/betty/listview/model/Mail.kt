package com.betty.listview.model

data class Mail(val content: String, val date: String, val sender: String)