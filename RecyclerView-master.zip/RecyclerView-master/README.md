<kbd>:hibiscus: Recycler view</kbd>


![CleanShot 2023-10-28 at 20 01 15](https://github.com/betty2310/RecyclerView/assets/75170473/5edb98e7-4335-4a8a-be67-86931610a15e)
